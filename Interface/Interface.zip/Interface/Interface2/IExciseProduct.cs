namespace Interface2
{
    public interface IExciseProduct
    {
        void CountTax(object obj);
    }
}