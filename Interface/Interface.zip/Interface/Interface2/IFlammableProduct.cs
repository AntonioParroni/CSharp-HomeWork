namespace Interface2
{
    public interface IFlammableProduct
    {
        void Inflammable(object obj);
        void Inflammable();
    }
}