namespace Interface2
{
    public interface IPerishableFood
    {
        void IsExpired(object obj);
    }
}