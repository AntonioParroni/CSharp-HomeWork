namespace Interface2
{
    public interface IFragileProduct
    {
        void Broke(object obj);
    }
}